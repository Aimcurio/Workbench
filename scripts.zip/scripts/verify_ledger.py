#!/usr/bin/env python3
"""
Multi-Provider Ledger Audit Script — Universal LLM Workbench (Task 10 / Phase 2)

Independently reads `ledger.jsonl`, parses each line as a LedgerRecord,
validates schema integrity, re-computes SHA-256 hashes of `wireBodyString` and `wireResponseBytes`,
verifies exact hash match across all multi-provider entries (anthropic, openai, ollama, custom),
and outputs provider-level audit statistics and exit codes.
"""

import sys
import os
import json
import hashlib
from pathlib import Path
from collections import defaultdict

REQUIRED_FIELDS = [
    "requestId",
    "timestampIso",
    "provider",
    "model",
    "endpoint",
    "wireBodyString",
    "wireBodyHash",
    "wireResponseBytes",
    "wireResponseHash",
    "httpStatus",
    "latencyMs",
    "error",
]

def resolve_ledger_path() -> Path:
    if len(sys.argv) > 1 and sys.argv[1].strip():
        arg_path = Path(sys.argv[1].strip())
        if arg_path.exists():
            return arg_path

    appdata_path = Path(os.path.expandvars(r"%LOCALAPPDATA%\com.universal.llm.workbench\ledger.jsonl"))
    if appdata_path.exists():
        return appdata_path

    workspace_path = Path("ledger.jsonl")
    if workspace_path.exists():
        return workspace_path

    return appdata_path

def audit_ledger() -> int:
    ledger_path = resolve_ledger_path()
    print("=== Universal LLM Workbench -- Multi-Provider Ledger Audit ===")
    print(f"Target Ledger Path: {ledger_path}\n")

    if not ledger_path.exists():
        print(f"FAILED: Ledger file does not exist at {ledger_path}")
        return 1

    total_records = 0
    passed_records = 0
    failed_records = 0

    provider_stats = defaultdict(lambda: {"total": 0, "passed": 0, "failed": 0})

    with open(ledger_path, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue

            total_records += 1
            print(f"--- Record #{total_records} (Line {line_num}) ---")

            try:
                record = json.loads(line)
            except json.JSONDecodeError as e:
                print(f"  [FAIL] Malformed JSON on line {line_num}: {e}")
                failed_records += 1
                provider_stats["malformed"]["failed"] += 1
                continue

            missing_fields = [field for field in REQUIRED_FIELDS if field not in record]
            if missing_fields:
                print(f"  [FAIL] Missing required fields: {missing_fields}")
                failed_records += 1
                provider_stats["malformed"]["failed"] += 1
                continue

            provider = record.get("provider", "unknown").lower()
            req_id = record["requestId"]
            wire_body_string = record["wireBodyString"]
            wire_body_hash_stored = record["wireBodyHash"]
            wire_response_bytes = record["wireResponseBytes"]
            wire_response_hash_stored = record["wireResponseHash"]

            computed_body_hash = hashlib.sha256(wire_body_string.encode("utf-8")).hexdigest()
            computed_response_hash = hashlib.sha256(wire_response_bytes.encode("utf-8")).hexdigest()

            body_match = computed_body_hash == wire_body_hash_stored
            response_match = computed_response_hash == wire_response_hash_stored

            provider_stats[provider]["total"] += 1

            print(f"  requestId:            {req_id}")
            print(f"  provider/model:       [{provider}] {record['model']}")
            print(f"  endpoint:             {record['endpoint']}")
            print(f"  httpStatus:           {record['httpStatus']} (latency: {record['latencyMs']} ms)")

            if not body_match:
                print(f"  [MISMATCH] wireBodyHash:")
                print(f"     Stored:   {wire_body_hash_stored}")
                print(f"     Computed: {computed_body_hash}")

            if not response_match:
                print(f"  [MISMATCH] wireResponseHash:")
                print(f"     Stored:   {wire_response_hash_stored}")
                print(f"     Computed: {computed_response_hash}")

            if body_match and response_match:
                print(f"  wireBodyHash:         {wire_body_hash_stored} (MATCH)")
                print(f"  wireResponseHash:     {wire_response_hash_stored} (MATCH)")
                print(f"  Result:               PASS [OK]")
                passed_records += 1
                provider_stats[provider]["passed"] += 1
            else:
                print(f"  Result:               FAIL [ERROR]")
                failed_records += 1
                provider_stats[provider]["failed"] += 1

    print("\n==============================================")
    print("MULTI-PROVIDER AUDIT SUMMARY STATISTICS:")
    print(f"  Total Records Audited: {total_records}")
    print(f"  Passed:                {passed_records}")
    print(f"  Failed:                {failed_records}")
    print("\n  Provider Breakdown:")
    for prov, stats in sorted(provider_stats.items()):
        print(f"    - {prov:<12}: Total: {stats['total']}, Passed: {stats['passed']}, Failed: {stats['failed']}")
    print("==============================================")

    if total_records == 0:
        print("  [FAIL] Audit FAILED: No records found in ledger.")
        return 1

    if failed_records == 0 and passed_records == total_records:
        print("  [SUCCESS] AUDIT PASSED: 100% of multi-provider ledger records verified successfully.")
        return 0
    else:
        print(f"  [FAIL] AUDIT FAILED: {failed_records} record(s) failed verification.")
        return 1

if __name__ == "__main__":
    sys.exit(audit_ledger())
