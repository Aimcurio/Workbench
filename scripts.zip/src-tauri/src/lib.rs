pub mod providers;
pub mod types;

use sha2::{Digest, Sha256};
use std::io::Write;
use tauri::Emitter;
use tauri::Manager;

pub use providers::{
    check_provider_api_key, delete_provider_api_key, get_provider_api_key, prepare_provider_request,
    set_provider_api_key,
};
pub use types::{LedgerRecord, LlmChunkEvent, LlmDoneEvent, SendLlmRequestResult};

pub fn get_api_key() -> Result<String, String> {
    get_provider_api_key("anthropic")?
        .ok_or_else(|| "API key not found in OS keyring ('anthropic' / 'api_key')".to_string())
}

fn iso8601_now() -> String {
    let now = std::time::SystemTime::now();
    let duration = now.duration_since(std::time::UNIX_EPOCH).unwrap_or_default();
    let secs = duration.as_secs();
    let millis = duration.subsec_millis();

    let days = secs / 86400;
    let day_secs = secs % 86400;
    let hours = day_secs / 3600;
    let minutes = (day_secs % 3600) / 60;
    let seconds = day_secs % 60;

    let z = days as i64 + 719468;
    let era = (if z >= 0 { z } else { z - 146096 }) / 146097;
    let doe = (z - era * 146097) as u64;
    let yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = doy - (153 * mp + 2) / 5 + 1;
    let m = if mp < 10 { mp + 3 } else { mp - 9 };
    let year = if m <= 2 { y + 1 } else { y };

    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}.{:03}Z",
        year, m, d, hours, minutes, seconds, millis
    )
}

pub async fn execute_llm_request(
    app_handle: tauri::AppHandle,
    request_id: String,
    body_string: String,
    provider: Option<String>,
    endpoint: Option<String>,
) {
    let start_time = std::time::Instant::now();

    // Compute wireBodyHash
    let mut body_hasher = Sha256::new();
    body_hasher.update(body_string.as_bytes());
    let wire_body_hash = format!("{:x}", body_hasher.finalize());

    // Extract model from body_string for convenience
    let model = serde_json::from_str::<serde_json::Value>(&body_string)
        .ok()
        .and_then(|v| v.get("model").and_then(|m| m.as_str()).map(|s| s.to_string()))
        .unwrap_or_else(|| "unknown".to_string());

    let client = reqwest::Client::new();
    let (target_provider, target_endpoint, request_builder) = match prepare_provider_request(
        &client,
        provider.as_deref(),
        endpoint.as_deref(),
        &body_string,
    ) {
        Ok(resolved) => (resolved.provider, resolved.endpoint, resolved.request_builder),
        Err(err) => {
            let latency_ms = start_time.elapsed().as_millis() as u64;
            let done_event = LlmDoneEvent {
                request_id: request_id.clone(),
                http_status: 0,
                wire_body_hash: wire_body_hash.clone(),
                wire_response_hash: format!("{:x}", Sha256::digest(b"")),
                latency_ms,
                error: Some(err),
            };
            let _ = app_handle.emit("llm-done", &done_event);
            return;
        }
    };

    let mut wire_response_bytes = String::new();
    let mut http_status: u16 = 0;
    let mut error: Option<String> = None;
    let mut seq: u32 = 0;

    match request_builder.send().await {
        Ok(mut response) => {
            http_status = response.status().as_u16();
            if !response.status().is_success() {
                error = Some(format!("HTTP {}", http_status));
            }

            loop {
                match response.chunk().await {
                    Ok(Some(chunk)) => {
                        let chunk_str = String::from_utf8_lossy(&chunk).to_string();
                        wire_response_bytes.push_str(&chunk_str);

                        let chunk_event = LlmChunkEvent {
                            request_id: request_id.clone(),
                            seq,
                            chunk_bytes: chunk_str,
                        };
                        let _ = app_handle.emit("llm-chunk", &chunk_event);
                        seq += 1;
                    }
                    Ok(None) => {
                        break;
                    }
                    Err(e) => {
                        error = Some(e.to_string());
                        break;
                    }
                }
            }
        }
        Err(e) => {
            error = Some(e.to_string());
        }
    }

    let latency_ms = start_time.elapsed().as_millis() as u64;

    // Compute wireResponseHash
    let mut res_hasher = Sha256::new();
    res_hasher.update(wire_response_bytes.as_bytes());
    let wire_response_hash = format!("{:x}", res_hasher.finalize());

    // Append LedgerRecord to ledger.jsonl
    let ledger_record = LedgerRecord {
        request_id: request_id.clone(),
        timestamp_iso: iso8601_now(),
        provider: target_provider,
        model,
        endpoint: target_endpoint,
        wire_body_string: body_string,
        wire_body_hash: wire_body_hash.clone(),
        wire_response_bytes,
        wire_response_hash: wire_response_hash.clone(),
        http_status,
        latency_ms,
        error: error.clone(),
    };

    if let Ok(app_dir) = app_handle.path().app_local_data_dir() {
        let _ = std::fs::create_dir_all(&app_dir);
        let ledger_path = app_dir.join("ledger.jsonl");
        if let Ok(json_line) = serde_json::to_string(&ledger_record) {
            if let Ok(mut file) = std::fs::OpenOptions::new()
                .create(true)
                .append(true)
                .open(&ledger_path)
            {
                let _ = writeln!(file, "{}", json_line);
            }
        }
    }

    // Emit llm-done event
    let done_event = LlmDoneEvent {
        request_id,
        http_status,
        wire_body_hash,
        wire_response_hash,
        latency_ms,
        error,
    };
    let _ = app_handle.emit("llm-done", &done_event);
}

#[tauri::command]
fn send_llm_request(
    app_handle: tauri::AppHandle,
    body_string: String,
    provider: Option<String>,
    endpoint: Option<String>,
) -> Result<SendLlmRequestResult, String> {
    let client = reqwest::Client::new();
    let _ = prepare_provider_request(
        &client,
        provider.as_deref(),
        endpoint.as_deref(),
        &body_string,
    )?;

    let request_id = uuid::Uuid::new_v4().to_string();
    let result = SendLlmRequestResult {
        request_id: request_id.clone(),
    };

    let app_handle_clone = app_handle.clone();
    let request_id_clone = request_id;

    tauri::async_runtime::spawn(async move {
        execute_llm_request(
            app_handle_clone,
            request_id_clone,
            body_string,
            provider,
            endpoint,
        )
        .await;
    });

    Ok(result)
}

#[tauri::command]
fn set_provider_key(provider: String, api_key: String) -> Result<(), String> {
    set_provider_api_key(&provider, &api_key)
}

#[tauri::command]
fn check_provider_key(provider: String) -> Result<bool, String> {
    check_provider_api_key(&provider)
}

#[tauri::command]
fn delete_provider_key(provider: String) -> Result<(), String> {
    delete_provider_api_key(&provider)
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_opener::init())
        .invoke_handler(tauri::generate_handler![
            send_llm_request,
            set_provider_key,
            check_provider_key,
            delete_provider_key
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
