use keyring::Entry;

pub fn get_provider_api_key(service: &str) -> Result<Option<String>, String> {
    let entry = Entry::new(service, "api_key").map_err(|e| format!("Failed to access OS keyring: {}", e))?;
    match entry.get_password() {
        Ok(key) if !key.trim().is_empty() => Ok(Some(key.trim().to_string())),
        Ok(_) => Ok(None),
        Err(keyring::Error::NoEntry) => Ok(None),
        Err(e) => Err(format!("Keyring error for '{}': {}", service, e)),
    }
}

pub fn set_provider_api_key(service: &str, api_key: &str) -> Result<(), String> {
    if api_key.trim().is_empty() {
        return Err("API key cannot be empty".to_string());
    }
    let entry = Entry::new(service, "api_key").map_err(|e| format!("Failed to access OS keyring: {}", e))?;
    entry
        .set_password(api_key.trim())
        .map_err(|e| format!("Failed to set API key in OS keyring: {}", e))?;
    Ok(())
}

pub fn check_provider_api_key(service: &str) -> Result<bool, String> {
    let key = get_provider_api_key(service)?;
    Ok(key.is_some())
}

pub fn delete_provider_api_key(service: &str) -> Result<(), String> {
    let entry = Entry::new(service, "api_key").map_err(|e| format!("Failed to access OS keyring: {}", e))?;
    match entry.delete_credential() {
        Ok(_) => Ok(()),
        Err(keyring::Error::NoEntry) => Ok(()),
        Err(e) => Err(format!("Failed to delete API key from OS keyring: {}", e)),
    }
}

pub struct ResolvedProviderTarget {
    pub provider: String,
    pub endpoint: String,
    pub request_builder: reqwest::RequestBuilder,
}

pub fn prepare_provider_request(
    client: &reqwest::Client,
    provider: Option<&str>,
    endpoint: Option<&str>,
    body_string: &str,
) -> Result<ResolvedProviderTarget, String> {
    let provider_norm = provider.unwrap_or("anthropic").to_lowercase();

    let default_endpoint = match provider_norm.as_str() {
        "openai" => "https://api.openai.com/v1/chat/completions",
        "ollama" => "http://localhost:11434/api/chat",
        "custom" => "http://localhost:8080/v1/chat/completions",
        _ => "https://api.anthropic.com/v1/messages",
    };

    let target_endpoint = endpoint
        .filter(|s| !s.trim().is_empty())
        .unwrap_or(default_endpoint)
        .to_string();

    let mut req = client
        .post(&target_endpoint)
        .header("content-type", "application/json")
        .body(body_string.to_string());

    match provider_norm.as_str() {
        "openai" => {
            let key = get_provider_api_key("openai")?
                .ok_or_else(|| "API key not found in OS keyring ('openai' / 'api_key')".to_string())?;
            req = req.header("Authorization", format!("Bearer {}", key));
        }
        "ollama" | "custom" => {
            if let Ok(Some(key)) = get_provider_api_key(&provider_norm) {
                req = req.header("Authorization", format!("Bearer {}", key));
            }
        }
        _ => {
            let key = get_provider_api_key("anthropic")?
                .ok_or_else(|| "API key not found in OS keyring ('anthropic' / 'api_key')".to_string())?;
            req = req.header("x-api-key", &key).header("anthropic-version", "2023-06-01");
        }
    }

    Ok(ResolvedProviderTarget {
        provider: provider_norm,
        endpoint: target_endpoint,
        request_builder: req,
    })
}
