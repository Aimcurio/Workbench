use serde::{Deserialize, Serialize};

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct SendLlmRequestArgs {
    pub body_string: String,
    pub provider: Option<String>,
    pub endpoint: Option<String>,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct SendLlmRequestResult {
    pub request_id: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct LlmChunkEvent {
    pub request_id: String,
    pub seq: u32,
    pub chunk_bytes: String,
}

#[derive(Serialize, Deserialize, Clone, Debug)]
#[serde(rename_all = "camelCase")]
pub struct LlmDoneEvent {
    pub request_id: String,
    pub http_status: u16,
    pub wire_body_hash: String,
    pub wire_response_hash: String,
    pub latency_ms: u64,
    pub error: Option<String>,
}

#[derive(Serialize, Deserialize, Debug)]
#[serde(rename_all = "camelCase")]
pub struct LedgerRecord {
    pub request_id: String,
    pub timestamp_iso: String,
    pub provider: String,
    pub model: String,
    pub endpoint: String,
    pub wire_body_string: String,
    pub wire_body_hash: String,
    pub wire_response_bytes: String,
    pub wire_response_hash: String,
    pub http_status: u16,
    pub latency_ms: u64,
    pub error: Option<String>,
}
