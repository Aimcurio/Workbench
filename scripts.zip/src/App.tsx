import { useState, useRef, useEffect, useCallback, useMemo } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen, UnlistenFn } from "@tauri-apps/api/event";
import {
  SendLlmRequestResult,
  LlmChunkEvent,
  LlmDoneEvent,
  ConversationSession,
  SessionMessage,
} from "./types";
import {
  loadSessionsFromStorage,
  saveSessionsToStorage,
  loadActiveSessionId,
  saveActiveSessionId,
  createNewSession,
} from "./services/sessionStore";
import { Inspector } from "./components/Inspector";
import { KeyManagerModal } from "./components/KeyManagerModal";
import { Sidebar } from "./components/Sidebar";
import { FailureTaggingModal } from "./components/FailureTaggingModal";
import { EvalSuite } from "./components/EvalSuite";
import { ChatMessageThread } from "./components/ChatMessageThread";
import "./App.css";

function App() {
  const [viewMode, setViewMode] = useState<"live" | "eval">("live");

  // Session State Persistence
  const [sessions, setSessions] = useState<ConversationSession[]>(() => {
    const loaded = loadSessionsFromStorage();
    if (loaded.length > 0) return loaded;
    const first = createNewSession();
    return [first];
  });

  const [activeSessionId, setActiveSessionId] = useState<string | null>(() => {
    const loadedId = loadActiveSessionId();
    const stored = loadSessionsFromStorage();
    if (loadedId && stored.some((s) => s.id === loadedId)) {
      return loadedId;
    }
    return stored.length > 0 ? stored[0].id : null;
  });

  // Ensure activeSessionId is valid
  useEffect(() => {
    if (!activeSessionId && sessions.length > 0) {
      setActiveSessionId(sessions[0].id);
    }
    saveSessionsToStorage(sessions);
  }, [sessions, activeSessionId]);

  useEffect(() => {
    saveActiveSessionId(activeSessionId);
  }, [activeSessionId]);

  const activeSession = sessions.find((s) => s.id === activeSessionId) || sessions[0];

  // All historical assistant turns across all sessions for side-by-side diffing
  const allTurns = useMemo(() => {
    const turns: SessionMessage[] = [];
    sessions.forEach((s) => {
      s.messages.forEach((m) => {
        if (m.role === "assistant" && m.requestId) {
          turns.push(m);
        }
      });
    });
    return turns;
  }, [sessions]);

  // Active Dispatch Settings
  const [provider, setProvider] = useState<string>(activeSession?.provider || "anthropic");
  const [model, setModel] = useState<string>(activeSession?.model || "claude-3-5-sonnet-20241022");
  const [customEndpoint, setCustomEndpoint] = useState<string>(activeSession?.customEndpoint || "");
  const [prompt, setPrompt] = useState("");

  // Sync settings when active session changes
  useEffect(() => {
    if (activeSession) {
      setProvider(activeSession.provider);
      setModel(activeSession.model);
      setCustomEndpoint(activeSession.customEndpoint || "");
    }
  }, [activeSessionId]);

  // Telemetry & Inspector State for Active or Selected Message Turn
  const [selectedMessageId, setSelectedMessageId] = useState<string | null>(null);
  const [clientRequestBodyString, setClientRequestBodyString] = useState<string | null>(null);
  const [requestId, setRequestId] = useState<string | null>(null);
  const [isStreaming, setIsStreaming] = useState(false);
  const [rawResponseBytes, setRawResponseBytes] = useState("");
  const [chunks, setChunks] = useState<LlmChunkEvent[]>([]);
  const [doneEvent, setDoneEvent] = useState<LlmDoneEvent | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Failure Tagging Modal State
  const [taggingModalOpen, setTaggingModalOpen] = useState(false);
  const [taggingTargetMsg, setTaggingTargetMsg] = useState<SessionMessage | null>(null);
  const [taggingPromptText, setTaggingPromptText] = useState("");

  const [isKeyManagerOpen, setIsKeyManagerOpen] = useState(false);
  const [keyHealth, setKeyHealth] = useState<{ anthropic: boolean; openai: boolean }>({
    anthropic: false,
    openai: false,
  });

  const activeUnlistensRef = useRef<UnlistenFn[]>([]);

  const refreshHealth = useCallback(async () => {
    try {
      const ant = await invoke<boolean>("check_provider_key", { provider: "anthropic" });
      const oai = await invoke<boolean>("check_provider_key", { provider: "openai" });
      setKeyHealth({ anthropic: ant, openai: oai });
    } catch (err) {
      console.error("[refreshHealth error]:", err);
    }
  }, []);

  useEffect(() => {
    refreshHealth();
  }, [refreshHealth]);

  const handleProviderChange = (newProvider: string) => {
    setProvider(newProvider);
    let newModel = "claude-3-5-sonnet-20241022";
    if (newProvider === "openai") {
      newModel = "gpt-4o-mini";
    } else if (newProvider === "custom" || newProvider === "ollama") {
      newModel = "local-model";
    }
    setModel(newModel);

    // Update active session settings
    if (activeSession) {
      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSession.id
            ? { ...s, provider: newProvider, model: newModel, updatedAtIso: new Date().toISOString() }
            : s
        )
      );
    }
  };

  const cleanupListeners = () => {
    activeUnlistensRef.current.forEach((unlisten) => unlisten());
    activeUnlistensRef.current = [];
  };

  // Session Handlers
  const handleCreateSession = () => {
    const newSession = createNewSession(provider, model);
    setSessions((prev) => [newSession, ...prev]);
    setActiveSessionId(newSession.id);
    setSelectedMessageId(null);
    setPrompt("");
    setRawResponseBytes("");
    setChunks([]);
    setDoneEvent(null);
    setErrorMsg(null);
  };

  const handleRenameSession = (id: string, newTitle: string) => {
    setSessions((prev) =>
      prev.map((s) => (s.id === id ? { ...s, title: newTitle, updatedAtIso: new Date().toISOString() } : s))
    );
  };

  const handleDeleteSession = (id: string) => {
    setSessions((prev) => {
      const filtered = prev.filter((s) => s.id !== id);
      if (filtered.length === 0) {
        const fresh = createNewSession();
        setActiveSessionId(fresh.id);
        return [fresh];
      }
      if (activeSessionId === id) {
        setActiveSessionId(filtered[0].id);
      }
      return filtered;
    });
  };

  // Rehydrate Turn Telemetry into Inspector
  const inspectMessageTurn = (msg: SessionMessage) => {
    setSelectedMessageId(msg.id);
    setRequestId(msg.requestId || null);
    setClientRequestBodyString(msg.clientRequestBodyString || null);
    setRawResponseBytes(msg.rawResponseBytes || "");
    setChunks(msg.chunks || []);
    setDoneEvent(msg.doneEvent || null);
    setErrorMsg(msg.errorMsg || null);
  };

  // Open Tagging Modal
  const openFailureTagging = (msg: SessionMessage, e: React.MouseEvent) => {
    e.stopPropagation();
    let promptText = "";
    if (activeSession) {
      const idx = activeSession.messages.findIndex((m) => m.id === msg.id);
      if (idx > 0 && activeSession.messages[idx - 1].role === "user") {
        promptText = activeSession.messages[idx - 1].content;
      }
    }
    setTaggingTargetMsg(msg);
    setTaggingPromptText(promptText || prompt);
    setTaggingModalOpen(true);
  };

  // Current active turn being viewed/inspected
  const currentTurn = useMemo(() => {
    if (selectedMessageId) {
      return activeSession?.messages.find((m) => m.id === selectedMessageId) || null;
    }
    const lastAst = activeSession?.messages.filter((m) => m.role === "assistant").pop();
    return lastAst || null;
  }, [selectedMessageId, activeSession]);

  const dispatchLlmRequest = async (
    promptText: string,
    reqProvider: string,
    reqModel: string,
    reqEndpoint?: string
  ) => {
    if (!promptText.trim() || isStreaming || !activeSession) return;

    cleanupListeners();
    setSelectedMessageId(null);
    setRequestId(null);
    setIsStreaming(true);
    setRawResponseBytes("");
    setChunks([]);
    setDoneEvent(null);
    setErrorMsg(null);

    // Create user message
    const userMsgId = `msg-user-${Date.now()}`;
    const userMsg: SessionMessage = {
      id: userMsgId,
      role: "user",
      content: promptText,
      timestampIso: new Date().toISOString(),
    };

    // Update active session title if first message
    const updatedTitle =
      activeSession.messages.length === 0
        ? promptText.substring(0, 30) + (promptText.length > 30 ? "..." : "")
        : activeSession.title;

    setSessions((prev) =>
      prev.map((s) =>
        s.id === activeSession.id
          ? {
              ...s,
              title: updatedTitle,
              updatedAtIso: new Date().toISOString(),
              messages: [...s.messages, userMsg],
            }
          : s
      )
    );

    // 1. Build JSON request body string
    const bodyObj: any = {
      model: reqModel,
      messages: [
        ...activeSession.messages.map((m) => ({ role: m.role, content: m.content })),
        { role: "user", content: promptText },
      ],
      stream: true,
    };
    if (reqProvider === "anthropic") {
      bodyObj.max_tokens = 1024;
    }
    const bodyString = JSON.stringify(bodyObj);
    setClientRequestBodyString(bodyString);

    let accumulatedBytes = "";
    let accumulatedChunks: LlmChunkEvent[] = [];
    let currentReqId = "";

    try {
      // 2. Register listen() listeners BEFORE calling invoke('send_llm_request', ...)
      const unlistenChunk = await listen<LlmChunkEvent>("llm-chunk", (event) => {
        const chunk = event.payload;
        console.log(`[llm-chunk] seq:${chunk.seq} reqId:${chunk.requestId} bytes:`, chunk.chunkBytes);
        accumulatedChunks.push(chunk);
        accumulatedBytes += chunk.chunkBytes;

        setChunks([...accumulatedChunks]);
        setRawResponseBytes(accumulatedBytes);
      });

      const unlistenDone = await listen<LlmDoneEvent>("llm-done", (event) => {
        const done = event.payload;
        console.log("[llm-done]", done);
        setDoneEvent(done);
        setIsStreaming(false);
        cleanupListeners();

        // Append Assistant Message to Session Store
        const assistantMsgId = `msg-ast-${Date.now()}`;
        const assistantMsg: SessionMessage = {
          id: assistantMsgId,
          role: "assistant",
          content: accumulatedBytes,
          requestId: done.requestId || currentReqId,
          timestampIso: new Date().toISOString(),
          provider: reqProvider,
          model: reqModel,
          endpoint: reqEndpoint,
          clientRequestBodyString: bodyString,
          rawResponseBytes: accumulatedBytes,
          chunks: accumulatedChunks,
          doneEvent: done,
          errorMsg: done.error,
        };

        setSessions((prev) =>
          prev.map((s) =>
            s.id === activeSession.id
              ? {
                  ...s,
                  updatedAtIso: new Date().toISOString(),
                  messages: [...s.messages, assistantMsg],
                }
              : s
          )
        );

        setSelectedMessageId(assistantMsgId);
      });

      activeUnlistensRef.current = [unlistenChunk, unlistenDone];

      // 3. Invoke send_llm_request command (returns requestId immediately)
      const res = await invoke<SendLlmRequestResult>("send_llm_request", {
        bodyString,
        provider: reqProvider,
        endpoint: reqProvider === "custom" || reqProvider === "ollama" ? reqEndpoint || null : null,
      });
      console.log("[send_llm_request] Returned immediately with requestId:", res.requestId);
      currentReqId = res.requestId;
      setRequestId(res.requestId);
    } catch (err: any) {
      console.error("[send_llm_request Error]", err);
      const errMsg = typeof err === "string" ? err : err.message || String(err);
      setErrorMsg(errMsg);
      setIsStreaming(false);
      cleanupListeners();

      // Append Failed Assistant Message to Session Store
      const assistantMsgId = `msg-ast-${Date.now()}`;
      const assistantMsg: SessionMessage = {
        id: assistantMsgId,
        role: "assistant",
        content: accumulatedBytes || `Request failed: ${errMsg}`,
        requestId: currentReqId,
        timestampIso: new Date().toISOString(),
        provider: reqProvider,
        model: reqModel,
        clientRequestBodyString: bodyString,
        rawResponseBytes: accumulatedBytes,
        chunks: accumulatedChunks,
        errorMsg: errMsg,
      };

      setSessions((prev) =>
        prev.map((s) =>
          s.id === activeSession.id
            ? {
                ...s,
                updatedAtIso: new Date().toISOString(),
                messages: [...s.messages, assistantMsg],
              }
            : s
        )
      );

      setSelectedMessageId(assistantMsgId);
    }
  };

  const handleSendRequest = () => {
    const text = prompt.trim();
    if (!text) return;
    setPrompt("");
    dispatchLlmRequest(text, provider, model, customEndpoint);
  };

  // Replay target turn
  const handleReplayTurn = (targetTurn: SessionMessage) => {
    let replayPrompt = "";
    if (targetTurn.clientRequestBodyString) {
      try {
        const parsed = JSON.parse(targetTurn.clientRequestBodyString);
        if (parsed.messages && Array.isArray(parsed.messages)) {
          const lastUser = parsed.messages.filter((m: any) => m.role === "user").pop();
          if (lastUser) replayPrompt = lastUser.content;
        }
      } catch {
        // Fallback
      }
    }
    if (!replayPrompt) {
      replayPrompt = "Replay prompt execution";
    }

    const reqProvider = targetTurn.provider || provider;
    const reqModel = targetTurn.model || model;
    const reqEndpoint = targetTurn.endpoint || customEndpoint;

    dispatchLlmRequest(replayPrompt, reqProvider, reqModel, reqEndpoint);
  };

  return (
    <div className="workbench-container" style={{ maxWidth: "1350px" }}>
      <header className="workbench-header">
        <div>
          <h1 className="workbench-title">Universal LLM Workbench</h1>
          <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.25rem", alignItems: "center" }}>
            <span className="badge">Task 12 — Zero-Abstraction Wire View</span>
            <span className={keyHealth.anthropic ? "badge status-success" : "badge status-error"}>
              Anthropic: {keyHealth.anthropic ? "✓ Key Present" : "✕ Key Missing"}
            </span>
            <span className={keyHealth.openai ? "badge status-success" : "badge status-error"}>
              OpenAI: {keyHealth.openai ? "✓ Key Present" : "✕ Key Missing"}
            </span>
          </div>
        </div>

        <div style={{ display: "flex", gap: "0.75rem", alignItems: "center" }}>
          {/* View Mode Switcher */}
          <div className="inspector-tabs" style={{ display: "flex", gap: "0.25rem" }}>
            <button
              className={`btn-tab ${viewMode === "live" ? "active" : ""}`}
              onClick={() => setViewMode("live")}
            >
              💬 Live Workspace
            </button>
            <button
              className={`btn-tab ${viewMode === "eval" ? "active" : ""}`}
              onClick={() => setViewMode("eval")}
            >
              📊 Eval Suite
            </button>
          </div>

          <button className="btn-secondary" onClick={() => setIsKeyManagerOpen(true)}>
            ⚙ Keyring Settings
          </button>
        </div>
      </header>

      {viewMode === "eval" ? (
        <EvalSuite activeProvider={provider} activeModel={model} activeEndpoint={customEndpoint} />
      ) : (
        <div style={{ display: "flex", gap: "1.5rem" }}>
          {/* Thread Indexing Sidebar */}
          <Sidebar
            sessions={sessions}
            activeSessionId={activeSessionId}
            onSelectSession={(id) => {
              setActiveSessionId(id);
              setSelectedMessageId(null);
            }}
            onCreateSession={handleCreateSession}
            onRenameSession={handleRenameSession}
            onDeleteSession={handleDeleteSession}
          />

          {/* Main Conversation & Dispatch View */}
          <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: "1.5rem" }}>
            <section className="card">
              <h2 className="card-title">Dispatch Configuration</h2>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
                <div className="form-group">
                  <label htmlFor="provider-select">Provider Target</label>
                  <select
                    id="provider-select"
                    value={provider}
                    onChange={(e) => handleProviderChange(e.target.value)}
                    disabled={isStreaming}
                  >
                    <option value="anthropic">Anthropic (Native Keyring)</option>
                    <option value="openai">OpenAI (Native Keyring)</option>
                    <option value="custom">Custom / Ollama (Unauthenticated / Local)</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="model-input">Model Name</label>
                  <input
                    id="model-input"
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    disabled={isStreaming}
                  />
                </div>
              </div>

              {(provider === "custom" || provider === "ollama") && (
                <div className="form-group">
                  <label htmlFor="endpoint-input">Custom Base Endpoint URL</label>
                  <input
                    id="endpoint-input"
                    type="text"
                    value={customEndpoint}
                    onChange={(e) => {
                      setCustomEndpoint(e.target.value);
                      if (activeSession) {
                        setSessions((prev) =>
                          prev.map((s) =>
                            s.id === activeSession.id ? { ...s, customEndpoint: e.target.value } : s
                          )
                        );
                      }
                    }}
                    placeholder="e.g. http://localhost:11434/api/chat or http://localhost:8080/v1/chat/completions"
                    disabled={isStreaming}
                  />
                </div>
              )}
            </section>

            {/* Zero-Abstraction Conversation Thread Pane */}
            {activeSession && (
              <section className="card">
                <h2 className="card-title">
                  Conversation Thread: {activeSession.title} ({activeSession.messages.length} messages)
                </h2>

                <ChatMessageThread
                  messages={activeSession.messages}
                  selectedMessageId={selectedMessageId}
                  isStreaming={isStreaming}
                  rawResponseBytes={rawResponseBytes}
                  chunks={chunks}
                  doneEvent={doneEvent}
                  activeProvider={provider}
                  activeModel={model}
                  onSelectTurn={inspectMessageTurn}
                  onTagFailure={openFailureTagging}
                  onReplayTurn={handleReplayTurn}
                />
              </section>
            )}

            {/* Prompt Entry Form */}
            <section className="card">
              <div className="form-group">
                <label htmlFor="prompt-input">Prompt Text (T0 User Input)</label>
                <textarea
                  id="prompt-input"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Enter prompt text here..."
                  disabled={isStreaming}
                />
              </div>

              <button
                className="btn-primary"
                onClick={handleSendRequest}
                disabled={isStreaming || !prompt.trim()}
              >
                {isStreaming ? "Streaming Response..." : "Send Request"}
              </button>
            </section>

            {/* Telemetry & Three-State Inspector Drawer Panel */}
            {(requestId || isStreaming || doneEvent || errorMsg || selectedMessageId || currentTurn) && (
              <>
                <section className="card">
                  <h2 className="card-title">Live Response Stream & Telemetry</h2>

                  <div className="status-bar" style={{ marginBottom: "1rem" }}>
                    <div className="status-item">
                      Request ID: <span>{requestId || "Pending..."}</span>
                    </div>
                    <div className="status-item">
                      Status:{" "}
                      <span
                        className={
                          isStreaming
                            ? "status-active"
                            : doneEvent?.error || errorMsg
                            ? "status-error"
                            : "status-success"
                        }
                      >
                        {isStreaming
                          ? "Streaming..."
                          : errorMsg
                          ? `Failed (${errorMsg})`
                          : doneEvent
                          ? `Done (HTTP ${doneEvent.httpStatus})`
                          : "Idle"}
                      </span>
                    </div>
                    {doneEvent && (
                      <div className="status-item">
                        Latency: <span>{doneEvent.latencyMs} ms</span>
                      </div>
                    )}
                  </div>

                  {doneEvent && (
                    <div
                      className="status-bar"
                      style={{ marginBottom: "1rem", flexWrap: "wrap" }}
                    >
                      <div className="status-item">
                        wireBodyHash: <span>{doneEvent.wireBodyHash}</span>
                      </div>
                      <div className="status-item">
                        wireResponseHash: <span>{doneEvent.wireResponseHash}</span>
                      </div>
                    </div>
                  )}

                  <div className="form-group">
                    <label>Raw Byte Stream Accumulator ({rawResponseBytes.length} bytes)</label>
                    <div className="stream-output">
                      {rawResponseBytes || (isStreaming ? "Waiting for first chunk..." : "No stream output.")}
                    </div>
                  </div>

                  <div className="form-group">
                    <label>emitted `llm-chunk` Events Log ({chunks.length} chunks received)</label>
                    <div className="chunks-log">
                      {chunks.map((c) => (
                        <div key={`${c.requestId}-${c.seq}`} className="chunk-row">
                          <span className="chunk-seq">#{c.seq}</span>
                          <span className="chunk-text">{JSON.stringify(c.chunkBytes)}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </section>

                <Inspector
                  userInputPrompt={currentTurn?.content || prompt}
                  clientRequestBodyString={clientRequestBodyString}
                  chunks={chunks}
                  rawResponseBytes={rawResponseBytes}
                  doneEvent={doneEvent}
                  allTurns={allTurns}
                  currentTurn={currentTurn}
                  onReplayTurn={handleReplayTurn}
                />
              </>
            )}
          </div>
        </div>
      )}

      {/* Key Manager / Settings Modal */}
      <KeyManagerModal
        isOpen={isKeyManagerOpen}
        onClose={() => setIsKeyManagerOpen(false)}
        onStatusChange={refreshHealth}
      />

      {/* Failure Case Tagging Modal */}
      <FailureTaggingModal
        isOpen={taggingModalOpen}
        onClose={() => setTaggingModalOpen(false)}
        targetMessage={taggingTargetMsg}
        userPromptText={taggingPromptText}
      />
    </div>
  );
}

export default App;
