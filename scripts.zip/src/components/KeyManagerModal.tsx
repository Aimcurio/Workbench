import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";

interface KeyManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStatusChange?: () => void;
}

interface ProviderInfo {
  id: string;
  name: string;
  description: string;
}

const PROVIDERS: ProviderInfo[] = [
  {
    id: "anthropic",
    name: "Anthropic",
    description: "Required for Claude 3.5 Sonnet and other Anthropic models.",
  },
  {
    id: "openai",
    name: "OpenAI",
    description: "Required for GPT-4o, GPT-4o-mini and OpenAI models.",
  },
];

export function KeyManagerModal({ isOpen, onClose, onStatusChange }: KeyManagerModalProps) {
  const [statuses, setStatuses] = useState<Record<string, boolean>>({});
  const [inputs, setInputs] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState<Record<string, boolean>>({});
  const [errorMsgs, setErrorMsgs] = useState<Record<string, string | null>>({});
  const [successMsgs, setSuccessMsgs] = useState<Record<string, string | null>>({});

  const checkKeys = useCallback(async () => {
    const newStatuses: Record<string, boolean> = {};
    for (const p of PROVIDERS) {
      try {
        const hasKey = await invoke<boolean>("check_provider_key", { provider: p.id });
        newStatuses[p.id] = hasKey;
      } catch (err) {
        console.error(`[check_provider_key error] for ${p.id}:`, err);
        newStatuses[p.id] = false;
      }
    }
    setStatuses(newStatuses);
    if (onStatusChange) onStatusChange();
  }, [onStatusChange]);

  useEffect(() => {
    if (isOpen) {
      checkKeys();
    }
  }, [isOpen, checkKeys]);

  if (!isOpen) return null;

  const handleSaveKey = async (providerId: string) => {
    const apiKey = inputs[providerId] || "";
    if (!apiKey.trim()) {
      setErrorMsgs((prev) => ({ ...prev, [providerId]: "Please enter an API key." }));
      return;
    }

    setLoading((prev) => ({ ...prev, [providerId]: true }));
    setErrorMsgs((prev) => ({ ...prev, [providerId]: null }));
    setSuccessMsgs((prev) => ({ ...prev, [providerId]: null }));

    try {
      await invoke("set_provider_key", { provider: providerId, apiKey: apiKey.trim() });
      setInputs((prev) => ({ ...prev, [providerId]: "" }));
      setSuccessMsgs((prev) => ({ ...prev, [providerId]: "Key securely saved in OS keyring." }));
      await checkKeys();
    } catch (err: any) {
      console.error(`[set_provider_key error] for ${providerId}:`, err);
      setErrorMsgs((prev) => ({
        ...prev,
        [providerId]: typeof err === "string" ? err : err.message || "Failed to save key.",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, [providerId]: false }));
    }
  };

  const handleDeleteKey = async (providerId: string) => {
    setLoading((prev) => ({ ...prev, [providerId]: true }));
    setErrorMsgs((prev) => ({ ...prev, [providerId]: null }));
    setSuccessMsgs((prev) => ({ ...prev, [providerId]: null }));

    try {
      await invoke("delete_provider_key", { provider: providerId });
      setSuccessMsgs((prev) => ({ ...prev, [providerId]: "Key removed from OS keyring." }));
      await checkKeys();
    } catch (err: any) {
      console.error(`[delete_provider_key error] for ${providerId}:`, err);
      setErrorMsgs((prev) => ({
        ...prev,
        [providerId]: typeof err === "string" ? err : err.message || "Failed to delete key.",
      }));
    } finally {
      setLoading((prev) => ({ ...prev, [providerId]: false }));
    }
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-content card" onClick={(e) => e.stopPropagation()} style={{ maxWidth: "600px", width: "90%" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <h2 className="card-title" style={{ margin: 0 }}>Keyring Settings & Credentials</h2>
          <button className="btn-secondary" onClick={onClose} style={{ padding: "0.25rem 0.75rem" }}>
            ✕ Close
          </button>
        </div>

        <p style={{ color: "#94a3b8", fontSize: "0.9rem", marginBottom: "1.5rem" }}>
          API credentials are stored securely in your native OS Keyring (Windows Credential Manager / macOS Keychain / Secret Service). Secret values are never exposed back to the webview DOM.
        </p>

        {PROVIDERS.map((p) => {
          const isConfigured = statuses[p.id] ?? false;
          const isBusy = loading[p.id] ?? false;

          return (
            <div key={p.id} className="provider-key-card" style={{ background: "#1e293b", padding: "1rem", borderRadius: "8px", marginBottom: "1rem" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "0.5rem" }}>
                <div>
                  <strong style={{ fontSize: "1.1rem" }}>{p.name}</strong>
                  <div style={{ fontSize: "0.85rem", color: "#94a3b8" }}>{p.description}</div>
                </div>
                <span className={isConfigured ? "badge status-success" : "badge status-error"} style={{ padding: "0.25rem 0.6rem" }}>
                  {isConfigured ? "✓ Configured" : "✕ Missing"}
                </span>
              </div>

              <div style={{ display: "flex", gap: "0.5rem", marginTop: "0.75rem" }}>
                <input
                  type="password"
                  value={inputs[p.id] || ""}
                  onChange={(e) => setInputs((prev) => ({ ...prev, [p.id]: e.target.value }))}
                  placeholder="Enter API key..."
                  disabled={isBusy}
                  style={{
                    flex: 1,
                    background: "#0f172a",
                    border: "1px solid #334155",
                    color: "#f8fafc",
                    padding: "0.5rem",
                    borderRadius: "4px",
                  }}
                />
                <button
                  className="btn-primary"
                  onClick={() => handleSaveKey(p.id)}
                  disabled={isBusy || !inputs[p.id]?.trim()}
                  style={{ padding: "0.5rem 1rem" }}
                >
                  Save Key
                </button>

                {isConfigured && (
                  <button
                    className="btn-secondary"
                    onClick={() => handleDeleteKey(p.id)}
                    disabled={isBusy}
                    style={{ padding: "0.5rem 1rem", color: "#ef4444", borderColor: "#ef4444" }}
                  >
                    Clear Key
                  </button>
                )}
              </div>

              {errorMsgs[p.id] && (
                <div style={{ color: "#f87171", fontSize: "0.85rem", marginTop: "0.5rem" }}>
                  Error: {errorMsgs[p.id]}
                </div>
              )}
              {successMsgs[p.id] && (
                <div style={{ color: "#4ade80", fontSize: "0.85rem", marginTop: "0.5rem" }}>
                  {successMsgs[p.id]}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
