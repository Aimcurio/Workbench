import { useState, useEffect, useCallback } from "react";
import { invoke } from "@tauri-apps/api/core";
import { listen, UnlistenFn } from "@tauri-apps/api/event";
import { FailureTestCase, SendLlmRequestResult, LlmChunkEvent, LlmDoneEvent } from "../types";
import { loadFailureCases, saveFailureCases, deleteFailureCase } from "../services/failureStore";

interface EvalSuiteProps {
  activeProvider: string;
  activeModel: string;
  activeEndpoint?: string;
}

export function EvalSuite({ activeProvider, activeModel, activeEndpoint }: EvalSuiteProps) {
  const [testCases, setTestCases] = useState<FailureTestCase[]>([]);
  const [isRunningBatch, setIsRunningBatch] = useState(false);
  const [currentRunningId, setCurrentRunningId] = useState<string | null>(null);

  const refreshCases = useCallback(() => {
    setTestCases(loadFailureCases());
  }, []);

  useEffect(() => {
    refreshCases();
  }, [refreshCases]);

  const handleDelete = (id: string) => {
    const updated = deleteFailureCase(id);
    setTestCases(updated);
  };

  // Run Batch Regression Test across all saved failure cases
  const handleRunBatchRegression = async () => {
    if (testCases.length === 0 || isRunningBatch) return;

    setIsRunningBatch(true);
    const updatedCases = [...testCases];

    for (let i = 0; i < updatedCases.length; i++) {
      const tc = updatedCases[i];
      setCurrentRunningId(tc.id);

      const bodyObj: any = {
        model: activeModel,
        messages: [{ role: "user", content: tc.userPrompt }],
        stream: true,
      };
      if (activeProvider === "anthropic") {
        bodyObj.max_tokens = 1024;
      }
      const bodyString = JSON.stringify(bodyObj);

      let accumulatedText = "";
      let newReqId = "";

      try {
        const unlistenChunk = await listen<LlmChunkEvent>("llm-chunk", (event) => {
          accumulatedText += event.payload.chunkBytes;
        });

        const donePromise = new Promise<LlmDoneEvent>((resolve) => {
          let unlistenDoneFn: UnlistenFn | null = null;
          listen<LlmDoneEvent>("llm-done", (event) => {
            unlistenChunk();
            if (unlistenDoneFn) unlistenDoneFn();
            resolve(event.payload);
          }).then((fn) => {
            unlistenDoneFn = fn;
          });
        });

        const res = await invoke<SendLlmRequestResult>("send_llm_request", {
          bodyString,
          provider: activeProvider,
          endpoint: activeProvider === "custom" || activeProvider === "ollama" ? activeEndpoint || null : null,
        });
        newReqId = res.requestId;

        const doneEvent = await donePromise;

        // Evaluate regression result: Check if output contains expected string or satisfies condition
        const textMatch =
          accumulatedText.trim().toLowerCase().includes(tc.expectedOutput.trim().toLowerCase()) ||
          (accumulatedText.trim().length > 0 && !doneEvent.error);

        const status: "passed" | "failed" | "error" = doneEvent.error
          ? "error"
          : textMatch
          ? "passed"
          : "failed";

        updatedCases[i] = {
          ...tc,
          lastRunResult: {
            runAtIso: new Date().toISOString(),
            newRequestId: newReqId,
            newOutput: accumulatedText,
            status,
            latencyMs: doneEvent.latencyMs,
            errorMsg: doneEvent.error || undefined,
          },
        };
      } catch (err: any) {
        console.error(`[EvalSuite] Batch regression error for ${tc.id}:`, err);
        updatedCases[i] = {
          ...tc,
          lastRunResult: {
            runAtIso: new Date().toISOString(),
            newRequestId: newReqId || "error-id",
            newOutput: "",
            status: "error",
            errorMsg: typeof err === "string" ? err : err.message || "Execution error",
          },
        };
      }

      setTestCases([...updatedCases]);
      saveFailureCases(updatedCases);
    }

    setIsRunningBatch(false);
    setCurrentRunningId(null);
  };

  // Calculate summary metrics
  const totalCases = testCases.length;
  const passedCases = testCases.filter((c) => c.lastRunResult?.status === "passed").length;
  const failedCases = testCases.filter((c) => c.lastRunResult?.status === "failed").length;
  const errorCases = testCases.filter((c) => c.lastRunResult?.status === "error").length;
  const testedCases = testCases.filter((c) => c.lastRunResult).length;
  const passRate = testedCases > 0 ? Math.round((passedCases / testedCases) * 100) : 0;

  return (
    <div className="eval-suite-container" style={{ display: "flex", flexDirection: "column", gap: "1.5rem" }}>
      {/* Header & Controls */}
      <section className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <div>
            <h2 className="card-title" style={{ margin: 0 }}>Evaluation Benchmark & Regression Suite</h2>
            <div style={{ fontSize: "0.85rem", color: "#94a3b8", marginTop: "0.25rem" }}>
              Targeting Provider: <code>{activeProvider}</code> | Model: <code>{activeModel}</code>
            </div>
          </div>

          <button
            className="btn-primary"
            onClick={handleRunBatchRegression}
            disabled={isRunningBatch || totalCases === 0}
            style={{ background: "#0284c7", borderColor: "#38bdf8", color: "#f8fafc" }}
          >
            {isRunningBatch ? "Executing Batch Regression..." : "▶ Run Batch Regression Suite"}
          </button>
        </div>

        {/* Summary Telemetry Bar */}
        <div className="status-bar" style={{ display: "flex", gap: "1.5rem", flexWrap: "wrap" }}>
          <div className="status-item">
            Total Failure Cases: <span>{totalCases}</span>
          </div>
          <div className="status-item">
            Regressions Tested: <span>{testedCases} / {totalCases}</span>
          </div>
          <div className="status-item">
            Passes: <span className="status-success">{passedCases}</span>
          </div>
          <div className="status-item">
            Failures: <span className="status-error">{failedCases + errorCases}</span>
          </div>
          <div className="status-item">
            Regression Pass Rate: <span className={passRate >= 70 ? "status-success" : "status-error"}>{passRate}%</span>
          </div>
        </div>
      </section>

      {/* Itemized Benchmark Dataset Table */}
      <section className="card">
        <h3 className="card-title">Failure Dataset ({totalCases} Cases)</h3>

        {totalCases === 0 ? (
          <div style={{ padding: "2rem 0", textAlign: "center", color: "#64748b", fontSize: "0.9rem" }}>
            No failure cases tagged yet. Tag message turns in the Live Workspace to populate the evaluation dataset.
          </div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "0.85rem", textAlign: "left" }}>
              <thead>
                <tr style={{ background: "#0f172a", borderBottom: "1px solid #334155", color: "#94a3b8" }}>
                  <th style={{ padding: "0.75rem" }}>Category</th>
                  <th style={{ padding: "0.75rem" }}>User Prompt</th>
                  <th style={{ padding: "0.75rem" }}>Expected Output</th>
                  <th style={{ padding: "0.75rem" }}>Original reqId</th>
                  <th style={{ padding: "0.75rem" }}>Last Regression Status</th>
                  <th style={{ padding: "0.75rem" }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {testCases.map((tc) => {
                  const isRunning = currentRunningId === tc.id;
                  const res = tc.lastRunResult;

                  return (
                    <tr key={tc.id} style={{ borderBottom: "1px solid #1e293b", background: isRunning ? "#334155" : "transparent" }}>
                      <td style={{ padding: "0.75rem" }}>
                        <span
                          className="badge"
                          style={{
                            background: "#334155",
                            color: tc.category === "Schema Violation" ? "#f87171" : tc.category === "Instruction Omission" ? "#fbbf24" : "#38bdf8",
                            padding: "0.2rem 0.5rem",
                          }}
                        >
                          {tc.category}
                        </span>
                      </td>

                      <td style={{ padding: "0.75rem", maxWidth: "220px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {tc.userPrompt}
                      </td>

                      <td style={{ padding: "0.75rem", maxWidth: "220px", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                        {tc.expectedOutput}
                      </td>

                      <td style={{ padding: "0.75rem" }}>
                        <code style={{ fontSize: "0.75rem", background: "#0f172a", padding: "0.15rem 0.4rem", borderRadius: "3px" }}>
                          {tc.requestId.substring(0, 8)}...
                        </code>
                      </td>

                      <td style={{ padding: "0.75rem" }}>
                        {isRunning ? (
                          <span className="status-active">Testing...</span>
                        ) : res ? (
                          <div style={{ display: "flex", flexDirection: "column", gap: "0.2rem" }}>
                            <span className={res.status === "passed" ? "status-success" : "status-error"}>
                              {res.status === "passed" ? "✓ PASSED" : `✕ FAILED (${res.errorMsg || "Mismatch"})`}
                            </span>
                            <code style={{ fontSize: "0.7rem", color: "#64748b" }}>
                              newReq: {res.newRequestId.substring(0, 8)}... ({res.latencyMs || 0}ms)
                            </code>
                          </div>
                        ) : (
                          <span style={{ color: "#64748b" }}>Not Tested</span>
                        )}
                      </td>

                      <td style={{ padding: "0.75rem" }}>
                        <button
                          onClick={() => handleDelete(tc.id)}
                          style={{ background: "none", border: "none", color: "#ef4444", cursor: "pointer", fontSize: "0.9rem" }}
                          title="Delete benchmark test case"
                        >
                          🗑
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
