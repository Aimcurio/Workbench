import { useState, useMemo } from "react";
import { SessionMessage } from "../types";

interface SideBySideDiffProps {
  allTurns: SessionMessage[];
  currentTurn?: SessionMessage | null;
}

export function SideBySideDiff({ allTurns, currentTurn }: SideBySideDiffProps) {
  const assistantTurns = useMemo(() => {
    return allTurns.filter((t) => t.role === "assistant" && t.requestId);
  }, [allTurns]);

  const [turnAId, setTurnAId] = useState<string>(() => {
    if (currentTurn && currentTurn.role === "assistant") return currentTurn.id;
    return assistantTurns[0]?.id || "";
  });

  const [turnBId, setTurnBId] = useState<string>(() => {
    if (assistantTurns.length > 1) {
      if (currentTurn && currentTurn.role === "assistant" && assistantTurns[0].id === currentTurn.id) {
        return assistantTurns[1].id;
      }
      return assistantTurns[assistantTurns.length - 1].id;
    }
    return assistantTurns[0]?.id || "";
  });

  const turnA = assistantTurns.find((t) => t.id === turnAId);
  const turnB = assistantTurns.find((t) => t.id === turnBId);

  if (assistantTurns.length === 0) {
    return (
      <div style={{ padding: "1rem", color: "#94a3b8", textAlign: "center" }}>
        No historical request turns available for comparison yet. Send or replay requests to enable Side-by-Side Diff.
      </div>
    );
  }

  // Compute metrics deltas
  const latencyA = turnA?.doneEvent?.latencyMs ?? 0;
  const latencyB = turnB?.doneEvent?.latencyMs ?? 0;
  const latencyDelta = latencyB - latencyA;

  const bytesA = turnA?.rawResponseBytes?.length ?? 0;
  const bytesB = turnB?.rawResponseBytes?.length ?? 0;
  const bytesDelta = bytesB - bytesA;

  const hashesMatch =
    turnA?.doneEvent?.wireResponseHash &&
    turnB?.doneEvent?.wireResponseHash &&
    turnA.doneEvent.wireResponseHash === turnB.doneEvent.wireResponseHash;

  const statusMatch = turnA?.doneEvent?.httpStatus === turnB?.doneEvent?.httpStatus;

  return (
    <div className="diff-container" style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      {/* Selection Control Panel */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem", background: "#0f172a", padding: "1rem", borderRadius: "6px" }}>
        <div className="form-group" style={{ margin: 0 }}>
          <label style={{ color: "#38bdf8", fontWeight: 600 }}>Turn A (Baseline)</label>
          <select value={turnAId} onChange={(e) => setTurnAId(e.target.value)}>
            {assistantTurns.map((t) => (
              <option key={`a-${t.id}`} value={t.id}>
                [{t.provider || "anthropic"}] reqId:{t.requestId?.substring(0, 8)}... ({new Date(t.timestampIso).toLocaleTimeString()})
              </option>
            ))}
          </select>
        </div>

        <div className="form-group" style={{ margin: 0 }}>
          <label style={{ color: "#4ade80", fontWeight: 600 }}>Turn B (Comparison / Replay)</label>
          <select value={turnBId} onChange={(e) => setTurnBId(e.target.value)}>
            {assistantTurns.map((t) => (
              <option key={`b-${t.id}`} value={t.id}>
                [{t.provider || "anthropic"}] reqId:{t.requestId?.substring(0, 8)}... ({new Date(t.timestampIso).toLocaleTimeString()})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Highlighting & Variance Summary */}
      <div className="status-bar" style={{ display: "flex", flexWrap: "wrap", gap: "1rem", justifyContent: "space-between" }}>
        <div className="status-item">
          SHA-256 Hash Integrity:{" "}
          <span className={hashesMatch ? "status-success" : "status-error"}>
            {hashesMatch ? "✓ Identical (100% Wire Match)" : "⚡ Hash Discrepancy (Variance Detected)"}
          </span>
        </div>

        <div className="status-item">
          Latency Delta (B vs A):{" "}
          <span className={latencyDelta <= 0 ? "status-success" : "status-error"}>
            {latencyDelta > 0 ? `+${latencyDelta} ms` : `${latencyDelta} ms`}
          </span>
        </div>

        <div className="status-item">
          Wire Bytes Delta:{" "}
          <span style={{ color: bytesDelta === 0 ? "#f8fafc" : "#38bdf8" }}>
            {bytesDelta > 0 ? `+${bytesDelta} bytes` : `${bytesDelta} bytes`}
          </span>
        </div>

        <div className="status-item">
          HTTP Status:{" "}
          <span className={statusMatch ? "status-success" : "status-error"}>
            Turn A ({turnA?.doneEvent?.httpStatus ?? "N/A"}) vs Turn B ({turnB?.doneEvent?.httpStatus ?? "N/A"})
          </span>
        </div>
      </div>

      {/* Side-by-Side Dual Column View */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "1rem" }}>
        {/* COLUMN A */}
        <div className="diff-column card" style={{ background: "#0f172a", border: "1px solid #38bdf8" }}>
          <h3 style={{ fontSize: "0.95rem", color: "#38bdf8", marginBottom: "0.75rem" }}>
            Turn A: [{turnA?.provider || "N/A"}] Model: {turnA?.model || "N/A"}
          </h3>

          <div className="form-group">
            <label>Request ID</label>
            <code style={{ fontSize: "0.8rem", background: "#1e293b", padding: "0.3rem", borderRadius: "4px" }}>
              {turnA?.requestId || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>wireBodyHash (SHA-256)</label>
            <code style={{ fontSize: "0.75rem", background: "#1e293b", padding: "0.3rem", borderRadius: "4px" }}>
              {turnA?.doneEvent?.wireBodyHash || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>wireResponseHash (SHA-256)</label>
            <code
              style={{
                fontSize: "0.75rem",
                background: "#1e293b",
                padding: "0.3rem",
                borderRadius: "4px",
                color: hashesMatch ? "#4ade80" : "#f87171",
              }}
            >
              {turnA?.doneEvent?.wireResponseHash || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>Extracted Output Text ($T_2$)</label>
            <div className="stream-output" style={{ maxHeight: "200px", fontSize: "0.85rem" }}>
              {turnA?.content || "(Empty)"}
            </div>
          </div>
        </div>

        {/* COLUMN B */}
        <div className="diff-column card" style={{ background: "#0f172a", border: "1px solid #4ade80" }}>
          <h3 style={{ fontSize: "0.95rem", color: "#4ade80", marginBottom: "0.75rem" }}>
            Turn B: [{turnB?.provider || "N/A"}] Model: {turnB?.model || "N/A"}
          </h3>

          <div className="form-group">
            <label>Request ID</label>
            <code style={{ fontSize: "0.8rem", background: "#1e293b", padding: "0.3rem", borderRadius: "4px" }}>
              {turnB?.requestId || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>wireBodyHash (SHA-256)</label>
            <code style={{ fontSize: "0.75rem", background: "#1e293b", padding: "0.3rem", borderRadius: "4px" }}>
              {turnB?.doneEvent?.wireBodyHash || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>wireResponseHash (SHA-256)</label>
            <code
              style={{
                fontSize: "0.75rem",
                background: "#1e293b",
                padding: "0.3rem",
                borderRadius: "4px",
                color: hashesMatch ? "#4ade80" : "#f87171",
              }}
            >
              {turnB?.doneEvent?.wireResponseHash || "N/A"}
            </code>
          </div>

          <div className="form-group">
            <label>Extracted Output Text ($T_2$)</label>
            <div className="stream-output" style={{ maxHeight: "200px", fontSize: "0.85rem" }}>
              {turnB?.content || "(Empty)"}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
