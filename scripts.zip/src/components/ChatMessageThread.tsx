import React from "react";
import { SessionMessage, LlmChunkEvent, LlmDoneEvent } from "../types";
import { parseSseWireStream } from "../services/streamParser";
import { MarkdownRenderer } from "./MarkdownRenderer";

interface ChatMessageThreadProps {
  messages: SessionMessage[];
  selectedMessageId: string | null;
  isStreaming: boolean;
  rawResponseBytes: string;
  chunks: LlmChunkEvent[];
  doneEvent: LlmDoneEvent | null;
  activeProvider: string;
  activeModel: string;
  onSelectTurn: (msg: SessionMessage) => void;
  onTagFailure: (msg: SessionMessage, e: React.MouseEvent) => void;
  onReplayTurn: (msg: SessionMessage) => void;
}

export function ChatMessageThread({
  messages,
  selectedMessageId,
  isStreaming,
  rawResponseBytes,
  chunks,
  activeProvider,
  activeModel,
  onSelectTurn,
  onTagFailure,
  onReplayTurn,
}: ChatMessageThreadProps) {
  // Live streaming parsed content
  const liveParsed = parseSseWireStream(rawResponseBytes);

  return (
    <div className="chat-thread-container" style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      {messages.map((m, idx) => {
        const isUser = m.role === "user";
        const isSelected = m.id === selectedMessageId;
        const isCurrentlyStreamingTurn = isStreaming && !isUser && idx === messages.length - 1;

        // Parse stream content cleanly
        let displayContent = "";
        let reasoningContent = "";

        if (isUser) {
          displayContent = m.content;
        } else if (isCurrentlyStreamingTurn) {
          displayContent = liveParsed.content || "Streaming live wire tokens...";
          reasoningContent = liveParsed.reasoning;
        } else {
          // Parse historical assistant turn
          const parsed = m.rawResponseBytes ? parseSseWireStream(m.rawResponseBytes) : { content: "", reasoning: "" };
          displayContent = parsed.content || m.content;
          reasoningContent = parsed.reasoning;

          // Extra fallback for inline <thinking> tags in m.content
          if (!reasoningContent && m.content) {
            const thinkMatch = m.content.match(/<thinking>([\s\S]*?)<\/thinking>/i);
            if (thinkMatch) {
              reasoningContent = thinkMatch[1].trim();
              displayContent = m.content.replace(/<thinking>[\s\S]*?<\/thinking>/i, "").trim();
            }
          }
        }

        return (
          <div
            key={m.id || idx}
            onClick={() => !isUser && onSelectTurn(m)}
            className={`chat-turn-card ${isSelected ? "selected" : ""}`}
            style={{
              padding: "1rem",
              borderRadius: "8px",
              background: isUser ? "#0f172a" : isSelected ? "#13233d" : "#111a2e",
              border: isUser
                ? "1px solid #334155"
                : isSelected
                ? "1px solid #38bdf8"
                : "1px solid #1e293b",
              boxShadow: isSelected ? "0 0 12px rgba(56, 189, 248, 0.15)" : "none",
              cursor: !isUser ? "pointer" : "default",
              transition: "all 0.2s ease",
            }}
          >
            {/* Header: Role & Provider Tag */}
            <div
              className="chat-turn-header"
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                marginBottom: "0.6rem",
                paddingBottom: "0.5rem",
                borderBottom: "1px solid rgba(71, 85, 105, 0.3)",
                flexWrap: "wrap",
                gap: "0.5rem",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
                <span
                  style={{
                    fontWeight: 700,
                    fontSize: "0.85rem",
                    color: isUser ? "#38bdf8" : "#4ade80",
                    textTransform: "uppercase",
                    letterSpacing: "0.05em",
                  }}
                >
                  {isUser ? "USER" : "ASSISTANT"}
                </span>

                {!isUser && (
                  <span className="badge" style={{ background: "#1e293b", color: "#94a3b8", fontSize: "0.7rem" }}>
                    {m.provider || activeProvider} / {m.model || activeModel}
                  </span>
                )}
              </div>

              <span style={{ color: "#64748b", fontSize: "0.75rem" }}>
                {new Date(m.timestampIso).toLocaleTimeString()}
              </span>
            </div>

            {/* Model Thinking & Reasoning Stream Block (if present) */}
            {reasoningContent && (
              <div
                className="reasoning-block"
                style={{
                  background: "rgba(15, 23, 42, 0.8)",
                  borderLeft: "3px solid #fbbf24",
                  padding: "0.6rem 0.8rem",
                  borderRadius: "4px",
                  marginBottom: "0.75rem",
                  fontSize: "0.85rem",
                  color: "#d1d5db",
                  fontFamily: "monospace",
                }}
              >
                <div style={{ fontSize: "0.75rem", color: "#fbbf24", fontWeight: 600, marginBottom: "0.25rem" }}>
                  🧠 Model Reasoning & Internal Chain-of-Thought
                </div>
                <div style={{ whiteSpace: "pre-wrap" }}>{reasoningContent}</div>
              </div>
            )}

            {/* Clean Markdown Output Chat Bubble */}
            <div className="chat-bubble-content" style={{ fontSize: "0.93rem", color: "#f8fafc" }}>
              {isUser ? (
                <div style={{ whiteSpace: "pre-wrap" }}>{displayContent}</div>
              ) : (
                <MarkdownRenderer content={displayContent} />
              )}
            </div>

            {/* Minimalist Wire Signature Footer */}
            {!isUser && (
              <div
                className="chat-turn-footer"
                style={{
                  marginTop: "0.75rem",
                  paddingTop: "0.5rem",
                  borderTop: "1px dashed rgba(71, 85, 105, 0.3)",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  fontSize: "0.75rem",
                  flexWrap: "wrap",
                  gap: "0.5rem",
                }}
              >
                <div style={{ display: "flex", gap: "0.6rem", alignItems: "center" }}>
                  {m.requestId && (
                    <span className="badge" style={{ background: "#0f172a", color: "#38bdf8", fontFamily: "monospace" }}>
                      reqId: {m.requestId.substring(0, 8)}...
                    </span>
                  )}

                  {m.doneEvent && (
                    <span className={m.doneEvent.httpStatus === 200 ? "status-success" : "status-error"}>
                      HTTP {m.doneEvent.httpStatus} ({m.doneEvent.latencyMs} ms)
                    </span>
                  )}

                  {m.rawResponseBytes && (
                    <span style={{ color: "#64748b" }}>
                      {m.rawResponseBytes.length} bytes ({m.chunks?.length || 0} chunks)
                    </span>
                  )}
                </div>

                <div style={{ display: "flex", gap: "0.4rem", alignItems: "center" }}>
                  <button
                    className="btn-tab"
                    onClick={(e) => onTagFailure(m, e)}
                    style={{ padding: "0.15rem 0.45rem", fontSize: "0.7rem", color: "#ef4444", borderColor: "#ef4444" }}
                    title="Tag response turn as Failure Case in benchmark dataset"
                  >
                    🏷 Tag Failure
                  </button>

                  <button
                    className="btn-tab"
                    onClick={(e) => {
                      e.stopPropagation();
                      onReplayTurn(m);
                    }}
                    style={{ padding: "0.15rem 0.45rem", fontSize: "0.7rem", color: "#38bdf8", borderColor: "#0284c7" }}
                    title="Replay wire request with new requestId"
                  >
                    🔄 Replay
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })}

      {/* Live Stream Accumulator Overlay during active request streaming */}
      {isStreaming && (
        <div
          className="live-stream-card card"
          style={{
            background: "#0f172a",
            border: "1px solid #38bdf8",
            padding: "0.85rem 1rem",
            borderRadius: "8px",
          }}
        >
          <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "0.4rem", fontSize: "0.8rem" }}>
            <span className="status-active" style={{ fontWeight: 600 }}>
              ⚡ Live Wire Stream ({chunks.length} chunks parsed)
            </span>
            <span style={{ color: "#94a3b8" }}>{rawResponseBytes.length} bytes accumulated</span>
          </div>

          <div
            className="stream-output"
            style={{
              maxHeight: "80px",
              fontSize: "0.8rem",
              background: "#131f37",
              padding: "0.5rem 0.75rem",
              borderRadius: "4px",
              opacity: 0.8,
            }}
          >
            {liveParsed.content || "Parsing SSE stream deltas..."}
          </div>
        </div>
      )}
    </div>
  );
}
