import { useState } from "react";
import { ConversationSession } from "../types";

interface SidebarProps {
  sessions: ConversationSession[];
  activeSessionId: string | null;
  onSelectSession: (id: string) => void;
  onCreateSession: () => void;
  onRenameSession: (id: string, newTitle: string) => void;
  onDeleteSession: (id: string) => void;
}

export function Sidebar({
  sessions,
  activeSessionId,
  onSelectSession,
  onCreateSession,
  onRenameSession,
  onDeleteSession,
}: SidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const handleStartRename = (session: ConversationSession, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(session.id);
    setEditTitle(session.title);
  };

  const handleSaveRename = (id: string, e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (editTitle.trim()) {
      onRenameSession(id, editTitle.trim());
    }
    setEditingId(null);
  };

  return (
    <aside className="sidebar-container card" style={{ width: "280px", flexShrink: 0, padding: "1rem" }}>
      <button
        className="btn-primary"
        onClick={onCreateSession}
        style={{ width: "100%", marginBottom: "1rem", display: "flex", justifyContent: "center", alignItems: "center", gap: "0.5rem" }}
      >
        <span>+</span> New Conversation
      </button>

      <div style={{ fontSize: "0.85rem", fontWeight: 600, color: "#94a3b8", marginBottom: "0.75rem", textTransform: "uppercase" }}>
        Threads ({sessions.length})
      </div>

      <div className="sidebar-session-list" style={{ display: "flex", flexDirection: "column", gap: "0.5rem", maxHeight: "calc(100vh - 220px)", overflowY: "auto" }}>
        {sessions.length === 0 ? (
          <div style={{ color: "#64748b", fontSize: "0.85rem", textAlign: "center", padding: "1rem 0" }}>
            No sessions yet. Click "New Conversation" above.
          </div>
        ) : (
          sessions.map((session) => {
            const isActive = session.id === activeSessionId;
            const isEditing = session.id === editingId;

            return (
              <div
                key={session.id}
                onClick={() => onSelectSession(session.id)}
                style={{
                  padding: "0.6rem 0.75rem",
                  borderRadius: "6px",
                  background: isActive ? "#334155" : "#1e293b",
                  border: isActive ? "1px solid #38bdf8" : "1px solid #334155",
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  gap: "0.25rem",
                  transition: "all 0.2s ease",
                }}
              >
                {isEditing ? (
                  <form onSubmit={(e) => handleSaveRename(session.id, e)} onClick={(e) => e.stopPropagation()}>
                    <input
                      type="text"
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      onBlur={() => handleSaveRename(session.id)}
                      autoFocus
                      style={{
                        fontSize: "0.85rem",
                        padding: "0.25rem 0.5rem",
                        background: "#0f172a",
                        color: "#f8fafc",
                        border: "1px solid #38bdf8",
                        borderRadius: "4px",
                      }}
                    />
                  </form>
                ) : (
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <span
                      style={{
                        fontSize: "0.9rem",
                        fontWeight: isActive ? 600 : 400,
                        color: isActive ? "#f8fafc" : "#cbd5e1",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap",
                        maxWidth: "170px",
                      }}
                    >
                      {session.title || "Untitled Session"}
                    </span>

                    <div style={{ display: "flex", gap: "0.25rem" }} onClick={(e) => e.stopPropagation()}>
                      <button
                        title="Rename Title"
                        onClick={(e) => handleStartRename(session, e)}
                        style={{
                          background: "none",
                          border: "none",
                          color: "#94a3b8",
                          cursor: "pointer",
                          fontSize: "0.8rem",
                          padding: "0.1rem 0.3rem",
                        }}
                      >
                        ✎
                      </button>
                      <button
                        title="Delete Session"
                        onClick={() => onDeleteSession(session.id)}
                        style={{
                          background: "none",
                          border: "none",
                          color: "#ef4444",
                          cursor: "pointer",
                          fontSize: "0.8rem",
                          padding: "0.1rem 0.3rem",
                        }}
                      >
                        🗑
                      </button>
                    </div>
                  </div>
                )}

                <div style={{ display: "flex", justifyContent: "space-between", fontSize: "0.75rem", color: "#64748b" }}>
                  <span>{session.provider}</span>
                  <span>{session.messages.length} msg{session.messages.length !== 1 ? "s" : ""}</span>
                </div>
              </div>
            );
          })
        )}
      </div>
    </aside>
  );
}
