import React from "react";

interface MarkdownRendererProps {
  content: string;
}

export function MarkdownRenderer({ content }: MarkdownRendererProps) {
  if (!content) return null;

  // Split code blocks from regular markdown
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="markdown-container" style={{ display: "flex", flexDirection: "column", gap: "0.5rem" }}>
      {parts.map((part, idx) => {
        if (part.startsWith("```") && part.endsWith("```")) {
          // Extract language and code
          const firstLineEnd = part.indexOf("\n");
          let lang = "code";
          let codeText = part.slice(3, -3);

          if (firstLineEnd !== -1 && firstLineEnd < 20) {
            lang = part.slice(3, firstLineEnd).trim() || "code";
            codeText = part.slice(firstLineEnd + 1, -3);
          }

          return (
            <div
              key={idx}
              className="code-block-wrapper"
              style={{
                background: "#090d16",
                border: "1px solid #1e293b",
                borderRadius: "6px",
                margin: "0.5rem 0",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  background: "#0f172a",
                  padding: "0.3rem 0.75rem",
                  fontSize: "0.75rem",
                  color: "#38bdf8",
                  fontFamily: "monospace",
                  borderBottom: "1px solid #1e293b",
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <span>{lang}</span>
              </div>
              <pre
                style={{
                  padding: "0.75rem",
                  margin: 0,
                  fontSize: "0.85rem",
                  fontFamily: "var(--font-mono)",
                  color: "#f8fafc",
                  overflowX: "auto",
                  lineHeight: "1.5",
                }}
              >
                <code>{codeText}</code>
              </pre>
            </div>
          );
        }

        // Render inline markdown elements (bold, inline code, headers, lists)
        const lines = part.split("\n");
        return (
          <div key={idx} style={{ display: "flex", flexDirection: "column", gap: "0.3rem" }}>
            {lines.map((line, lIdx) => {
              const trimmed = line.trim();
              if (!trimmed) return <div key={lIdx} style={{ height: "0.3rem" }} />;

              // Headers
              if (trimmed.startsWith("### ")) {
                return (
                  <h4 key={lIdx} style={{ color: "#38bdf8", fontSize: "0.95rem", margin: "0.4rem 0 0.2rem" }}>
                    {renderInlineFormatting(trimmed.slice(4))}
                  </h4>
                );
              }
              if (trimmed.startsWith("## ")) {
                return (
                  <h3 key={lIdx} style={{ color: "#38bdf8", fontSize: "1.05rem", margin: "0.5rem 0 0.25rem" }}>
                    {renderInlineFormatting(trimmed.slice(3))}
                  </h3>
                );
              }
              if (trimmed.startsWith("# ")) {
                return (
                  <h2 key={lIdx} style={{ color: "#38bdf8", fontSize: "1.15rem", margin: "0.6rem 0 0.3rem" }}>
                    {renderInlineFormatting(trimmed.slice(2))}
                  </h2>
                );
              }

              // Bullet lists
              if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
                return (
                  <div key={lIdx} style={{ display: "flex", gap: "0.5rem", paddingLeft: "0.5rem" }}>
                    <span style={{ color: "#38bdf8" }}>•</span>
                    <span>{renderInlineFormatting(trimmed.slice(2))}</span>
                  </div>
                );
              }

              // Regular paragraph line
              return <div key={lIdx}>{renderInlineFormatting(line)}</div>;
            })}
          </div>
        );
      })}
    </div>
  );
}

function renderInlineFormatting(text: string): React.ReactNode {
  // Handle inline code `code` and bold **text**
  const regex = /(`[^`]+`|\*\*[^*]+\*\*|\*[^*]+\*)/g;
  const parts = text.split(regex);

  return parts.map((part, i) => {
    if (part.startsWith("`") && part.endsWith("`")) {
      return (
        <code
          key={i}
          style={{
            background: "#0f172a",
            color: "#38bdf8",
            padding: "0.1rem 0.35rem",
            borderRadius: "4px",
            fontFamily: "var(--font-mono)",
            fontSize: "0.85em",
            border: "1px solid #1e293b",
          }}
        >
          {part.slice(1, -1)}
        </code>
      );
    }
    if (part.startsWith("**") && part.endsWith("**")) {
      return <strong key={i} style={{ color: "#f8fafc", fontWeight: 700 }}>{part.slice(2, -2)}</strong>;
    }
    if (part.startsWith("*") && part.endsWith("*")) {
      return <em key={i} style={{ color: "#cbd5e1" }}>{part.slice(1, -1)}</em>;
    }
    return part;
  });
}
