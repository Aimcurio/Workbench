import { useState, useEffect } from "react";
import { FailureCategory, SessionMessage } from "../types";
import { addFailureCase } from "../services/failureStore";

interface FailureTaggingModalProps {
  isOpen: boolean;
  onClose: () => void;
  targetMessage: SessionMessage | null;
  userPromptText: string;
  onSaved?: () => void;
}

const FAILURE_CATEGORIES: FailureCategory[] = [
  "Schema Violation",
  "Instruction Omission",
  "Hallucination",
  "Reasoning Loop Failure",
];

export function FailureTaggingModal({
  isOpen,
  onClose,
  targetMessage,
  userPromptText,
  onSaved,
}: FailureTaggingModalProps) {
  const [category, setCategory] = useState<FailureCategory>("Schema Violation");
  const [expectedOutput, setExpectedOutput] = useState("");
  const [notes, setNotes] = useState("");
  const [savedSuccess, setSavedSuccess] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setSavedSuccess(false);
      setExpectedOutput("");
      setNotes("");
    }
  }, [isOpen]);

  if (!isOpen || !targetMessage) return null;

  const handleSave = () => {
    if (!expectedOutput.trim()) return;

    addFailureCase({
      requestId: targetMessage.requestId || "unregistered-id",
      category,
      userPrompt: userPromptText || "Prompt unavailable",
      actualOutput: targetMessage.content || "",
      expectedOutput: expectedOutput.trim(),
      provider: targetMessage.provider || "anthropic",
      model: targetMessage.model || "claude-3-5-sonnet-20241022",
      endpoint: targetMessage.endpoint,
      notes: notes.trim() || undefined,
    });

    setSavedSuccess(true);
    if (onSaved) onSaved();
    setTimeout(() => {
      onClose();
    }, 600);
  };

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div
        className="modal-content card"
        onClick={(e) => e.stopPropagation()}
        style={{ maxWidth: "600px", width: "90%" }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
          <h2 className="card-title" style={{ margin: 0 }}>Tag Failure Case & Evaluation Benchmark</h2>
          <button className="btn-secondary" onClick={onClose} style={{ padding: "0.25rem 0.75rem" }}>
            ✕ Close
          </button>
        </div>

        <div style={{ fontSize: "0.85rem", color: "#94a3b8", marginBottom: "1rem" }}>
          Link this response turn (reqId: <code>{targetMessage.requestId?.substring(0, 8)}...</code>) to the local evaluation dataset for regression testing.
        </div>

        <div className="form-group">
          <label>Failure Classification Category</label>
          <select value={category} onChange={(e) => setCategory(e.target.value as FailureCategory)}>
            {FAILURE_CATEGORIES.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Actual Output Produced ($T_2$)</label>
          <div className="stream-output" style={{ maxHeight: "100px", fontSize: "0.85rem", background: "#0f172a" }}>
            {targetMessage.content || "(No response content)"}
          </div>
        </div>

        <div className="form-group">
          <label style={{ color: "#4ade80", fontWeight: 600 }}>Expected Correct Output</label>
          <textarea
            value={expectedOutput}
            onChange={(e) => setExpectedOutput(e.target.value)}
            placeholder="Describe or paste the expected valid response..."
            rows={4}
          />
        </div>

        <div className="form-group">
          <label>Notes / Context (Optional)</label>
          <input
            type="text"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            placeholder="e.g. Model failed to format JSON keys in snake_case"
          />
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", gap: "0.5rem", marginTop: "1rem" }}>
          <button className="btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button
            className="btn-primary"
            onClick={handleSave}
            disabled={!expectedOutput.trim()}
            style={{ background: "#ef4444", borderColor: "#ef4444", color: "#ffffff" }}
          >
            {savedSuccess ? "Saved to Benchmark Dataset!" : "Save Failure Case"}
          </button>
        </div>
      </div>
    </div>
  );
}
