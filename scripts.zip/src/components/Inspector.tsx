import { useState, useMemo } from "react";
import { LlmChunkEvent, LlmDoneEvent, SessionMessage } from "../types";
import { SideBySideDiff } from "./SideBySideDiff";

interface InspectorProps {
  userInputPrompt: string;
  clientRequestBodyString: string | null;
  chunks: LlmChunkEvent[];
  rawResponseBytes: string;
  doneEvent: LlmDoneEvent | null;
  allTurns?: SessionMessage[];
  currentTurn?: SessionMessage | null;
  onReplayTurn?: (turn: SessionMessage) => void;
}

export function Inspector({
  userInputPrompt,
  clientRequestBodyString,
  chunks,
  rawResponseBytes,
  doneEvent,
  allTurns = [],
  currentTurn,
  onReplayTurn,
}: InspectorProps) {
  const [activeTab, setActiveTab] = useState<"stateA" | "stateB" | "stateC" | "transformations" | "diff">("stateA");

  // Transformation T1: Parse SSE lines
  const sseEvents = useMemo(() => {
    if (!rawResponseBytes) return [];
    const lines = rawResponseBytes.split("\n");
    const events: { event?: string; data?: string }[] = [];
    let currentEvent = "";

    lines.forEach((line) => {
      const trimmed = line.trim();
      if (trimmed.startsWith("event:")) {
        currentEvent = trimmed.replace("event:", "").trim();
      } else if (trimmed.startsWith("data:")) {
        const dataStr = trimmed.replace("data:", "").trim();
        events.push({ event: currentEvent || "message", data: dataStr });
        currentEvent = "";
      }
    });

    return events;
  }, [rawResponseBytes]);

  // Transformation T2: Extracted Text Payload from SSE events
  const extractedText = useMemo(() => {
    let text = "";
    sseEvents.forEach((ev) => {
      if (ev.data && ev.data !== "[DONE]") {
        try {
          const parsed = JSON.parse(ev.data);
          if (parsed.type === "content_block_delta" && parsed.delta?.text) {
            text += parsed.delta.text;
          } else if (parsed.content && Array.isArray(parsed.content)) {
            parsed.content.forEach((c: any) => {
              if (c.text) text += c.text;
            });
          }
        } catch {
          // If data isn't JSON or is raw text chunk
        }
      }
    });
    return text || "(No extracted text or error response)";
  }, [sseEvents]);

  return (
    <section className="card inspector-card" style={{ marginTop: "1.5rem" }}>
      <div className="inspector-header" style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem", flexWrap: "wrap", gap: "0.5rem" }}>
        <h2 className="card-title" style={{ margin: 0 }}>Three-State Inspection Plane</h2>

        <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
          {currentTurn && onReplayTurn && (
            <button
              className="btn-secondary"
              onClick={() => onReplayTurn(currentTurn)}
              style={{ background: "#0284c7", borderColor: "#38bdf8", color: "#f8fafc", padding: "0.35rem 0.8rem", fontSize: "0.8rem" }}
              title="Replay this exact request payload with a new unique requestId"
            >
              🔄 Replay Wire Request
            </button>
          )}

          <div className="inspector-tabs" style={{ display: "flex", gap: "0.5rem" }}>
            <button
              className={`btn-tab ${activeTab === "stateA" ? "active" : ""}`}
              onClick={() => setActiveTab("stateA")}
            >
              State A (T0: User Input)
            </button>
            <button
              className={`btn-tab ${activeTab === "stateB" ? "active" : ""}`}
              onClick={() => setActiveTab("stateB")}
            >
              State B (T1-T3: Client Body)
            </button>
            <button
              className={`btn-tab ${activeTab === "transformations" ? "active" : ""}`}
              onClick={() => setActiveTab("transformations")}
            >
              Derived (T1-T3 SSE View)
            </button>
            <button
              className={`btn-tab ${activeTab === "stateC" ? "active" : ""}`}
              onClick={() => setActiveTab("stateC")}
            >
              State C (Ledger & Wire)
            </button>
            <button
              className={`btn-tab ${activeTab === "diff" ? "active" : ""}`}
              onClick={() => setActiveTab("diff")}
            >
              Side-by-Side Diff
            </button>
          </div>
        </div>
      </div>

      {activeTab === "stateA" && (
        <div className="inspector-content">
          <div className="form-group">
            <label>State A — User Input (T0 Raw Prompt Text)</label>
            <div className="stream-output">
              {userInputPrompt || "(Empty Prompt)"}
            </div>
          </div>
          <div className="status-bar" style={{ marginTop: "0.5rem" }}>
            <div className="status-item">
              Raw Prompt Characters: <span>{userInputPrompt.length}</span>
            </div>
            <div className="status-item">
              Bytes (UTF-8): <span>{new TextEncoder().encode(userInputPrompt).length}</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === "stateB" && (
        <div className="inspector-content">
          <div className="form-group">
            <label>State B — Client Request (Exact `bodyString` Sent Over IPC)</label>
            <div className="stream-output">
              {clientRequestBodyString
                ? JSON.stringify(JSON.parse(clientRequestBodyString), null, 2)
                : "(No active request dispatched)"}
            </div>
          </div>
          <div className="status-bar" style={{ marginTop: "0.5rem" }}>
            <div className="status-item">
              `bodyString` Length: <span>{clientRequestBodyString?.length || 0} bytes</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === "transformations" && (
        <div className="inspector-content">
          <div className="form-group">
            <label>Transformation T1: Parsed SSE Stream Events ({sseEvents.length} events)</label>
            <div className="chunks-log" style={{ maxHeight: "150px" }}>
              {sseEvents.map((ev, idx) => (
                <div key={idx} className="chunk-row">
                  <span className="chunk-seq">Event #{idx + 1} [{ev.event}]</span>
                  <span className="chunk-text">{ev.data}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="form-group" style={{ marginTop: "1rem" }}>
            <label>Transformation T2: Assembled Message Text Payload</label>
            <div className="stream-output" style={{ maxHeight: "120px" }}>
              {extractedText}
            </div>
          </div>

          <div className="form-group" style={{ marginTop: "1rem" }}>
            <label>Transformation T3: Rendered Output</label>
            <div className="stream-output" style={{ backgroundColor: "var(--bg-secondary)", minHeight: "60px" }}>
              {extractedText}
            </div>
          </div>
        </div>
      )}

      {activeTab === "stateC" && (
        <div className="inspector-content">
          <div className="form-group">
            <label>State C — Wire Integrity & Ledger Telemetry</label>
            <div className="status-bar" style={{ flexDirection: "column", gap: "0.75rem" }}>
              <div className="status-item">
                Request ID: <span>{doneEvent?.requestId || "N/A"}</span>
              </div>
              <div className="status-item">
                HTTP Status: <span>{doneEvent?.httpStatus ?? "N/A"}</span>
              </div>
              <div className="status-item">
                wireBodyHash (SHA-256): <span>{doneEvent?.wireBodyHash || "N/A"}</span>
              </div>
              <div className="status-item">
                wireResponseHash (SHA-256): <span>{doneEvent?.wireResponseHash || "N/A"}</span>
              </div>
              <div className="status-item">
                Latency: <span>{doneEvent?.latencyMs ? `${doneEvent.latencyMs} ms` : "N/A"}</span>
              </div>
              <div className="status-item">
                Accumulated Wire Bytes: <span>{rawResponseBytes.length} bytes</span>
              </div>
              <div className="status-item">
                Total Chunks Received: <span>{chunks.length}</span>
              </div>
              <div className="status-item">
                Error Status: <span>{doneEvent?.error || "None (Success)"}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === "diff" && (
        <SideBySideDiff allTurns={allTurns} currentTurn={currentTurn} />
      )}
    </section>
  );
}
