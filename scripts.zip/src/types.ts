export interface SendLlmRequestArgs {
  bodyString: string;
  provider?: string;
  endpoint?: string;
}

export interface SendLlmRequestResult {
  requestId: string;
}

export interface LlmChunkEvent {
  requestId: string;
  seq: number;
  chunkBytes: string;
}

export interface LlmDoneEvent {
  requestId: string;
  httpStatus: number;
  wireBodyHash: string;
  wireResponseHash: string;
  latencyMs: number;
  error: string | null;
}

export interface SessionMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  requestId?: string;
  timestampIso: string;
  provider?: string;
  model?: string;
  endpoint?: string;
  clientRequestBodyString?: string;
  rawResponseBytes?: string;
  chunks?: LlmChunkEvent[];
  doneEvent?: LlmDoneEvent | null;
  errorMsg?: string | null;
}

export interface ConversationSession {
  id: string;
  title: string;
  createdAtIso: string;
  updatedAtIso: string;
  provider: string;
  model: string;
  customEndpoint?: string;
  messages: SessionMessage[];
}

export type FailureCategory =
  | "Schema Violation"
  | "Instruction Omission"
  | "Hallucination"
  | "Reasoning Loop Failure";

export interface FailureTestCase {
  id: string;
  requestId: string;
  createdAtIso: string;
  category: FailureCategory;
  expectedOutput: string;
  userPrompt: string;
  actualOutput: string;
  provider: string;
  model: string;
  endpoint?: string;
  notes?: string;
  lastRunResult?: {
    runAtIso: string;
    newRequestId: string;
    newOutput: string;
    status: "passed" | "failed" | "error";
    latencyMs?: number;
    errorMsg?: string;
  };
}
