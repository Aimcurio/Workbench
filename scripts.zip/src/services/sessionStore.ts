import { ConversationSession } from "../types";

const SESSIONS_KEY = "llm_workbench_sessions_v1";
const ACTIVE_SESSION_KEY = "llm_workbench_active_session_id_v1";

export function loadSessionsFromStorage(): ConversationSession[] {
  try {
    const raw = localStorage.getItem(SESSIONS_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error("[sessionStore] Failed to load sessions from localStorage:", err);
    return [];
  }
}

export function saveSessionsToStorage(sessions: ConversationSession[]): void {
  try {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  } catch (err) {
    console.error("[sessionStore] Failed to save sessions to localStorage:", err);
  }
}

export function loadActiveSessionId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_SESSION_KEY);
  } catch {
    return null;
  }
}

export function saveActiveSessionId(id: string | null): void {
  try {
    if (id) {
      localStorage.setItem(ACTIVE_SESSION_KEY, id);
    } else {
      localStorage.removeItem(ACTIVE_SESSION_KEY);
    }
  } catch {
    // Ignore storage errors
  }
}

export function createNewSession(provider = "anthropic", model = "claude-3-5-sonnet-20241022"): ConversationSession {
  const now = new Date().toISOString();
  return {
    id: `session-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    title: "New Conversation",
    createdAtIso: now,
    updatedAtIso: now,
    provider,
    model,
    messages: [],
  };
}
