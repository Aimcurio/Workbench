export interface ParsedStreamPayload {
  content: string;
  reasoning: string;
}

export function parseSseWireStream(rawBytes: string): ParsedStreamPayload {
  if (!rawBytes) {
    return { content: "", reasoning: "" };
  }

  let content = "";
  let reasoning = "";

  const lines = rawBytes.split("\n");

  for (let line of lines) {
    const trimmed = line.trim();

    // Check for SSE data line
    if (trimmed.startsWith("data:")) {
      const dataStr = trimmed.replace(/^data:\s*/, "").trim();
      if (dataStr === "[DONE]" || !dataStr) continue;

      try {
        const parsed = JSON.parse(dataStr);

        // 1. Anthropic SSE stream structures
        if (parsed.type === "content_block_delta") {
          if (parsed.delta?.text) {
            content += parsed.delta.text;
          }
        } else if (parsed.type === "thinking_delta" || parsed.delta?.type === "thinking_delta") {
          if (parsed.delta?.thinking) {
            reasoning += parsed.delta.thinking;
          }
        }

        // 2. OpenAI / Custom Chat Completions SSE structures
        if (parsed.choices && Array.isArray(parsed.choices)) {
          for (const choice of parsed.choices) {
            if (choice.delta) {
              if (choice.delta.reasoning_content) {
                reasoning += choice.delta.reasoning_content;
              }
              if (choice.delta.content) {
                content += choice.delta.content;
              }
            } else if (choice.text) {
              content += choice.text;
            }
          }
        }

        // 3. Ollama / Direct API JSON fallback
        if (parsed.message?.content) {
          content += parsed.message.content;
        } else if (parsed.response) {
          content += parsed.response;
        }
      } catch {
        // If dataStr is not JSON, use clean text if not raw json syntax
        if (!dataStr.startsWith("{") && !dataStr.startsWith("[")) {
          content += dataStr + " ";
        }
      }
    } else if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
      // Non-SSE single JSON payload fallback
      try {
        const parsed = JSON.parse(trimmed);
        if (parsed.content && Array.isArray(parsed.content)) {
          for (const block of parsed.content) {
            if (block.text) content += block.text;
          }
        } else if (parsed.choices && parsed.choices[0]?.message?.content) {
          content += parsed.choices[0].message.content;
        }
      } catch {
        // Ignore JSON parse errors
      }
    }
  }

  // Fallback: If content is still empty but rawBytes contains text without SSE prefixes
  if (!content && !reasoning) {
    // Check if rawBytes is plain text (not starting with data: or {)
    if (!rawBytes.trim().startsWith("data:") && !rawBytes.trim().startsWith("{")) {
      content = rawBytes;
    }
  }

  return { content: content.trim(), reasoning: reasoning.trim() };
}
