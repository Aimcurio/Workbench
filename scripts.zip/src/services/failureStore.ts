import { FailureTestCase } from "../types";

const FAILURE_CASES_KEY = "llm_workbench_failure_cases_v1";

export function loadFailureCases(): FailureTestCase[] {
  try {
    const raw = localStorage.getItem(FAILURE_CASES_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch (err) {
    console.error("[failureStore] Failed to load failure cases from localStorage:", err);
    return [];
  }
}

export function saveFailureCases(cases: FailureTestCase[]): void {
  try {
    localStorage.setItem(FAILURE_CASES_KEY, JSON.stringify(cases));
  } catch (err) {
    console.error("[failureStore] Failed to save failure cases to localStorage:", err);
  }
}

export function addFailureCase(
  testCase: Omit<FailureTestCase, "id" | "createdAtIso">
): FailureTestCase {
  const cases = loadFailureCases();
  const newEntry: FailureTestCase = {
    ...testCase,
    id: `eval-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    createdAtIso: new Date().toISOString(),
  };
  const updated = [newEntry, ...cases];
  saveFailureCases(updated);
  return newEntry;
}

export function updateFailureCase(
  id: string,
  updates: Partial<FailureTestCase>
): FailureTestCase[] {
  const cases = loadFailureCases();
  const updated = cases.map((c) => (c.id === id ? { ...c, ...updates } : c));
  saveFailureCases(updated);
  return updated;
}

export function deleteFailureCase(id: string): FailureTestCase[] {
  const cases = loadFailureCases();
  const updated = cases.filter((c) => c.id !== id);
  saveFailureCases(updated);
  return updated;
}
